package com.eggnews.eggnews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EggnewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
