package com.egg.libreriaEgg.enums;

/**
 * Enumera los roles existentes en el sistema.
 *
 * @author Mauro Montenegro <maumontenegro.s at gmail.com>
 */
public enum Rol {
    ADMIN, USUARIO
}
