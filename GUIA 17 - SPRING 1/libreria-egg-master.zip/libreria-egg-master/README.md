# libreria-egg
Proyecto de "Sistema de Gestión" de una biblioteca llamada "Librería EGG". El mismo cuenta con sistema de usuarios con dos tipos de rol:
- ADMIN (que puede gestionar la creación, modificación, alta/baja y eliminación de los libros/autores/editoriales registrados, además de gestionar préstamos para los usuarios);
- USUARIO (tiene la posibilidad de registrarse para poder solicitar préstamos de los libros disponibles en la biblioteca).

Este proyecto lo realicé como práctica para la última etapa del curso Desarrollador Web Full Stack del instituto Egg Coperation, utilizando Java (Spring Framework), MySQL, HTML, CSS y Bootstrap, con Thymeleaf.
