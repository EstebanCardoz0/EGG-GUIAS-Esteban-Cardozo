/*
 * Sin licencia.
 * Uso para capacitación
 * 2021 Año de la Prevención y Lucha contra el COVID-19.

Desarrollar  una  clase  Cancion  con  los  siguientes  atributos:  titulo  
y  autor.  Se  deberá definir además dos constructores: uno vacío que 
inicializa el titulo y el autor a cadenas vacías y otro que reciba como 
parámetros el titulo y el autor de la canción. Se deberán además definir 
los métodos getters y setters correspondientes. 

 */

package ej01;

/**
 *
 * @author Adrian E. Camus
 */
public class Main_ej01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // El Código va AQUI!!!
    }

}
