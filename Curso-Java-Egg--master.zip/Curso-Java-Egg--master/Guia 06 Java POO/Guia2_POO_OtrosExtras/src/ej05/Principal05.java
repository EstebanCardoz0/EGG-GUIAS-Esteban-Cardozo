/*
 * Sin licencia.
 * Uso para capacitación
 * 2021 Año de la Prevención y Lucha contra el COVID-19.

Ejercicio 5
Definir una clase triangulo que modelara triángulos isósceles . Definir los atributos necesarios para
operar. Crear los métodos correspondientes a la clase Entidad.
Crear un arreglo con 4 objetos de la clase
Crear los siguientes métodos:
 Calcular área
 Calcular perímetro
 Mostrar los datos del triángulo que tenga el área de mayor superficie

 */

package ej05;

/**
 *
 * @author Adrian E. Camus
 */
public class Principal05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // El Código va AQUI!!!
    }

}
