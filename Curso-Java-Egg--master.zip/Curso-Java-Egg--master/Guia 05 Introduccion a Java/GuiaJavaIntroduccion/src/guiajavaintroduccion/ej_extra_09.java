/*
 * Sin licencia.
 * Uso para capacitación
 * 2021 Año de la Prevención y Lucha contra el COVID-19.

    Simular la división usando solamente restas. Dados dos números enteros 
    mayores que uno, realizar un algoritmo que calcule el cociente y el 
    residuo usando sólo restas. Método: Restar el dividendo del divisor 
    hasta obtener un resultado menor que el divisor, este resultado es el 
    residuo, y el número de restas realizadas es el cociente. 
    Por ejemplo: 50 / 13: 

    50 –13 = 37 una resta realizada 
    37 –13 = 24 dos restas realizadas 
    24 –13 = 11 tres restas realizadas 
    dado que 11 es menor que 13, 
    entonces: el residuo es 11 y el cociente es 3

 */
package guiajavaintroduccion;

import java.util.Scanner;

/**
 *
 * @author Adrian E. Camus
 */
public class ej_extra_09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // El Código va AQUI!!!
        int resto, cociente = 0;
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingresa el dividendo");
        int dividendo = leer.nextInt();
        System.out.println("Ingresa el divisor");
        int divisor = leer.nextInt();

        resto = dividendo;

        if (dividendo > divisor) {

            while (resto > divisor) {
                resto = resto - divisor;
                cociente++;
            }
        } else {
            System.out.println("El dividendo debe ser mayor que el divisor");
        }
        if (resto==divisor){
            cociente++;
            resto=0;
        }
        System.out.println(dividendo + " / " + divisor + " = " + cociente);
        System.out.println("con un resto de " + resto);

    }

}
