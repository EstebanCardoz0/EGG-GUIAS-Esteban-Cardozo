/*
 * Sin licencia.
 * Uso para capacitación
 * 2021 Año de la Prevención y Lucha contra el COVID-19.

    Construya un programa que lea 5 palabras de mínimo 3 y hasta 5 caracteres 
    y, a medida que el usuario las va ingresando, construya una “sopa de 
    letras para niños” de tamaño de 20 x 20 caracteres. Las palabras se 
    ubicarán todas en orden horizontal en una fila que será seleccionada 
    de manera aleatoria. Una vez concluida la ubicación de las palabras, 
    rellene los espacios no utilizados con un número aleatorio del 0 al 9. 
    Finalmente imprima por pantalla la sopa de letras creada. 

    Nota:  Para  resolver  el  ejercicio  deberá  investigar  cómo  se utilizan
    las  siguientes funciones de Java substring(), Length() y Math.random(). 

 */
package guiajavaintroduccion;

/**
 *
 * @author Adrian E. Camus
 */
public class ej_extra_22 {
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    

}
