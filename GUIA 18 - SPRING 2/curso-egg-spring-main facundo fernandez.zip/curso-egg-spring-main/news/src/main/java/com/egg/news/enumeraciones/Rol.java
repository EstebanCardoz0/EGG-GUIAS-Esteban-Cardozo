package com.egg.news.enumeraciones;

public enum Rol {
  USER,
  ADMIN;
}
