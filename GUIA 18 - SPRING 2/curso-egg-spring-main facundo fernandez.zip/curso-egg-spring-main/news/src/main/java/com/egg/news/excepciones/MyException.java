package com.egg.news.excepciones;

public class MyException extends Exception {

  public MyException(String msg) {
    super(msg);
  }
}
