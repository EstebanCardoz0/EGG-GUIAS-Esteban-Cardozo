package com.egg.news.entidades;

import javax.persistence.Entity;

@Entity
public class Admin extends Usuario {

}
