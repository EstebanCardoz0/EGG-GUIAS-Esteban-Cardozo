package com.LaEstancia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaEstanciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaEstanciaApplication.class, args);
	}

}
