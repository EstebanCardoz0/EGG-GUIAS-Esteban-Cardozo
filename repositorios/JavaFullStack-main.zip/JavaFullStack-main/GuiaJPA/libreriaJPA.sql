create database libreriaJPA;
use libreriajpa;
select * from autor;
select * from libro;