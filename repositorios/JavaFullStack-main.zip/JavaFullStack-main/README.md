# JavaFullStack
Repositorio con ejercicios resueltos en curso de Java full stack desde marzo de 2021 hasta diciembre del 2021

Curso intensivo de Java dado por la empresa Egg en asociacion con la empresa G&L Group en el cual utilice los siguientes lenguajes:
- [x] PseInt
- [x] Java
- [x] MySQL
- [x] Union de Java con SQL mediante JDBC
- [x] Union de Java con SQL mediante JPA
- [x] HTML
- [x] CSS
- [x] BootStrap   
- [x] Java Spring Boot
- [x] Proyecto final grupal integrador de todos los temas vistos       
