create database libreria_web;
drop database libreria_web;
use libreria_web;
select * from libro;
select * from autor;
select * from editorial;
update autor set alta = false where id = 2;
delete from autor where id = 4;

