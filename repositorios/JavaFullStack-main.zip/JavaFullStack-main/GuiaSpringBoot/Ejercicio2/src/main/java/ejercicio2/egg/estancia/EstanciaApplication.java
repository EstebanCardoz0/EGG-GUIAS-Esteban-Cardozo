package ejercicio2.egg.estancia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstanciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstanciaApplication.class, args);
	}

}
