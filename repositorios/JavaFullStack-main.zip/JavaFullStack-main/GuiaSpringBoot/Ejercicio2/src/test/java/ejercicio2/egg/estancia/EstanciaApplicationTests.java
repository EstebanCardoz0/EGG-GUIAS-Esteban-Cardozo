package ejercicio2.egg.estancia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstanciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
