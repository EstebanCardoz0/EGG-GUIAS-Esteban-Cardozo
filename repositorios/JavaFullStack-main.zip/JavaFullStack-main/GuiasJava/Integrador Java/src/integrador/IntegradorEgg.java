package integrador;

public class IntegradorEgg {

    public static void main(String[] args) {
        
        Practica practica = new Practica();
        
        System.out.println( (int) Math.log10(1000)+1);
        
    }
}
