package jdbc.principal;

import jdbc.excepcion.MiExcepcion;
import jdbc.menu.MenuEstancias;

public class Ejercicio2JDBC {

    public static void main(String[] args) throws MiExcepcion {
        MenuEstancias menu = new MenuEstancias();
        
        menu.interfaz();
    }
    
}
