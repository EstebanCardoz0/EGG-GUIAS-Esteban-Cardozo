package jdbc.persistencia;

public class ComentariosDAO extends DAO{
    
}
