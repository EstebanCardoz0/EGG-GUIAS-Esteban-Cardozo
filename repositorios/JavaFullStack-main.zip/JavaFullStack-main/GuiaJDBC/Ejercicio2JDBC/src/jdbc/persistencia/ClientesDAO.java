package jdbc.persistencia;

public class ClientesDAO extends DAO{
    
}
