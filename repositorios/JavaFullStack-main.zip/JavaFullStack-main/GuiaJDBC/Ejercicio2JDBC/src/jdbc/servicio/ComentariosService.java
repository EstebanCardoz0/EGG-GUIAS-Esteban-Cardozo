package jdbc.servicio;


public class ComentariosService {
    
}
