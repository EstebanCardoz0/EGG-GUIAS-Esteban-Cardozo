/*
 * Sin licencia.
 * Uso para capacitación
 * 2021 Año de la Prevención y Lucha contra el COVID-19.
 */
package ej_01.enumeraciones;

/**
 *
 * @author Adrian E. Camus
 */
public enum Tamanio {
    GRANDE, MEDIANO, HISTERICO;
}
