/*
 * Sin licencia.
 * Uso para capacitación
 * 2021 Año de la Prevención y Lucha contra el COVID-19.
 */
package enumeradores;

/**
 *
 * @author Mesa 9
 */
public enum Consumo {
    A,B,C,D,E,F;
}
