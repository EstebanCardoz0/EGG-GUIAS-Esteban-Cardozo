package com.Estancia.Enum;

public enum Role {
	FAMILIA, CLIENTE;
}
