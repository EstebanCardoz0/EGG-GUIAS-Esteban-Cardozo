package com.Estancia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstanciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
