# EggCourse
This guide belongs to the Egg Course (https://eggeducacion.com/es-AR/). Where there are theoretical and practical exercises on Programming. The language to work is java, touching topics such as: Object Orientation, Collections, Relationships between classes, Inheritance, Exceptions, JDBC, JPA. In databases we work with MySQL. On the front end there is work with HTML, CSS, Bootstrap. And projects with Spring.

# Beginning  :biking_man:
The archive contains folders, where each folder is a Java project containing the exercises of the course mentioned above (except the database exercises, where the files are sql scripts). 

# Certification

![GitHubParaSubir](https://user-images.githubusercontent.com/67133096/147526929-00429f37-4609-4a4b-a061-8c01bc87a27a.png)
