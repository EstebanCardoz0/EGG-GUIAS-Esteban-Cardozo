package estancias.servicios;

public class ClienteServicio {
}
