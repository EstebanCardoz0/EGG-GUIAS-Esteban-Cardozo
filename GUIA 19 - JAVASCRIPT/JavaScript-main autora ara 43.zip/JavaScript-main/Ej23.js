// function changeColor() {
//     let elem = document.getElementById('text1');
//     //elem.style.color = newColor;
//   }

//   function resaltarC(){
//     for(const e of changeColor()){
//         if(e > 8){
//             e.style.color = 'yellow';
//         }

//     }
//   }
